//
//  UIImage+XHGIF.h
//  XHLaunchAdExample
//
//  Created by xiaohui on 16/6/13.
//  Copyright © 2016年 CoderZhuXH. All rights reserved.
//  代码地址:https://github.com/CoderZhuXH/XHLaunchAd


#import <UIKit/UIKit.h>

@interface UIImage (XHGIF)

+(UIImage *)xh_animatedGIFWithData:(NSData *)data;

@end
