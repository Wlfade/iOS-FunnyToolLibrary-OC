﻿## 设置启动页为LaunchImage

#### 1.设置启动页为LaunchImage,方法如下:<br>
*    1.在Assets.xcassets中新建LaunchImage<br>
     2.在项目`TARGETS->General->App Icons and Launch Images`中设置 `Launch Images Source` 为LaunchImage,并将`Launch Screen File` 设为空(如图)<br>
     ![image](https://github.com/CoderZhuXH/XHLaunchAd/blob/master/LaunchImageSet/LaunchImageSet-01.png)

#### 2.在LaunchImage 添加相应启动图片<br>
*    1.如图<br>
     ![image](https://github.com/CoderZhuXH/XHLaunchAd/blob/master/LaunchImageSet/LaunchImageSet-02.png)
