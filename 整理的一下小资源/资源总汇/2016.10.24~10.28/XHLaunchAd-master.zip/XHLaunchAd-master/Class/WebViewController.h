//
//  WebViewController.h
//  XHLaunchAdExample
//
//  Created by xiaohui on 16/9/8.
//  Copyright © 2016年 CoderZhuXH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController

@property (nonatomic, copy) NSString *URLString;

@end
