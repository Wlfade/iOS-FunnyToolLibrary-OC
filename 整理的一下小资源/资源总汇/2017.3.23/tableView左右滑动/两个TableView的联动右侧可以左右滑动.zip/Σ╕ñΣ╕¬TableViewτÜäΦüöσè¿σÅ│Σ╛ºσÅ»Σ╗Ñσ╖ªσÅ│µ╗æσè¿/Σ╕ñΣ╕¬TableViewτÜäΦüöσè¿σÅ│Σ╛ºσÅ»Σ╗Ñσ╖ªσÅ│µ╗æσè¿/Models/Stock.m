//
//  Stock.m
//  两个TableView的联动右侧可以左右滑动
//
//  Created by jczj on 17/3/23.
//  Copyright © 2017年 jczj. All rights reserved.
//

#import "Stock.h"

@implementation Stock
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    //    NSLog(@"%@,%@",key,value);
    //    if ([key isEqualToString:@"id"]) {
    //        self.idStr = [NSString stringWithFormat:@"%@",value];
    //    }
}
@end
